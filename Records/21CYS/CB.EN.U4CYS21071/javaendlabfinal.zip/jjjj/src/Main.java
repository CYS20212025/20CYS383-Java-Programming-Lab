
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
/**
 * This is a simple java code to perform File management operations
 *
 *
 * @author Sourabh S
 *
 */

abstract class File {
    private String fileName;
    private long fileSize;

    public File(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public abstract String getFileDetails();
}

interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void displayAllFiles();
    void saveToFile();
    void loadFromFile();
    ArrayList<File> getFiles();
}

class FileManagerImpl implements FileManager {

    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(File file) {
        files.add(file);
    }

    public void deleteFile(String fileName) {
        for (File file : files) {
            if (file.getFileName().equals(fileName)) {
                files.remove(file);
                break;
            }
        }
    }

    public void displayAllFiles() {
        for (File file : files) {
            System.out.println(file.getFileDetails());
        }
    }

    public void saveToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("files.txt"))) {
            for (File file : files) {
                writer.println(file.getClass().getSimpleName() + "," + file.getFileName() + "," + file.getFileSize() + "," + file.getFileDetails());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("files.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 4) {
                    String fileClass = data[0];
                    String fileName = data[1];
                    long fileSize = Long.parseLong(data[2]);
                    if (fileClass.equals("Document")) {
                        String documentType = data[3];
                        addFile(new Document(fileName, fileSize, documentType));
                    } else if (fileClass.equals("Image")) {
                        String resolution = data[3];
                        addFile(new Image(fileName, fileSize, resolution));
                    } else if (fileClass.equals("Video")) {
                        String duration = data[3];
                        addFile(new Video(fileName, fileSize, duration));
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<File> getFiles() {
        return files;
    }
}

class Document extends File {
    private String documentType;

    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public String getFileDetails() {
        return "Document: " + getFileName() + " | Size: " + getFileSize() + " | Type: " + getDocumentType();
    }
}

class Image extends File {
    private String resolution;

    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }

    public String getFileDetails() {
        return "Image: " + getFileName() + " | Size: " + getFileSize() + " | Resolution: " + getResolution();
    }
}

class Video extends File {
    private String duration;

    public Video(String fileName, long fileSize, String duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    public String getDuration() {
        return duration;
    }

    public String getFileDetails() {
        return "Video: " + getFileName() + " | Size: " + getFileSize() + " | Duration: " + getDuration();
    }
}

class FileManagementSystemUI extends JFrame implements ActionListener {
    private JTextField nameField;
    private JTextField sizeField;
    private JTextField typeField;
    private JTextArea filesArea;
    private DefaultListModel<String> fileListModel;
    private JList<String> fileList;
    private FileManager fileManager;

    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();


        setTitle("File Management System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2));
        inputPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Size:"));
        sizeField = new JTextField();
        inputPanel.add(sizeField);
        inputPanel.add(new JLabel("FileType:"));
        typeField = new JTextField();
        inputPanel.add(typeField);
        JButton addButton = new JButton("Add");
        addButton.addActionListener(this);
        inputPanel.add(addButton);
        add(inputPanel, BorderLayout.NORTH);

        fileListModel = new DefaultListModel<>();
        fileList = new JList<>(fileListModel);
        fileList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(fileList), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(this);
        buttonPanel.add(deleteButton);
        JButton displayButton = new JButton("Display");
        displayButton.addActionListener(this);
        buttonPanel.add(displayButton);
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(this);
        buttonPanel.add(saveButton);
        JButton loadButton = new JButton("Load");
        loadButton.addActionListener(this);
        buttonPanel.add(loadButton);
        add(buttonPanel, BorderLayout.SOUTH);

        filesArea = new JTextArea();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("Add")) {
            String name = nameField.getText();
            long size = Long.parseLong(sizeField.getText());
            String type = typeField.getText();

            if (!type.isEmpty()) {
                fileManager.addFile(new Document(name, size, type));
                fileListModel.addElement(name);
            }

            nameField.setText("");
            sizeField.setText("");
            typeField.setText("");
        } else if (e.getActionCommand().equals("Delete")) {
            int selectedIndex = fileList.getSelectedIndex();
            if (selectedIndex != -1) {
                String selectedFileName = fileList.getSelectedValue();
                fileManager.deleteFile(selectedFileName);
                fileListModel.remove(selectedIndex);
            }
        } else if (e.getActionCommand().equals("Display")) {
            filesArea.setText("");
            ArrayList<File> files = fileManager.getFiles();
            for (File file : files) {
                filesArea.append(file.getFileDetails() + "\n");
            }
        } else if (e.getActionCommand().equals("Save")) {
            fileManager.saveToFile();
        } else if (e.getActionCommand().equals("Load")) {
            fileManager.loadFromFile();
            fileListModel.clear();
            ArrayList<File> files = fileManager.getFiles();
            for (File file : files) {
                fileListModel.addElement(file.getFileName());
            }
        }
    }
}
/**
 * Main class
 *
 */


public class Main {
    public static void main(String[] args) {
        System.out.println("Opening GUI File Manager");
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                FileManagementSystemUI ui = new FileManagementSystemUI();
                ui.setVisible(true);
            }
        });
    }
}
